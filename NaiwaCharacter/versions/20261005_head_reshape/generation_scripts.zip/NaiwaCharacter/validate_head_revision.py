"""Validate the current head-shape delivery against its fixed preceding version."""
import runpy
from pathlib import Path
runpy.run_path(str(Path(__file__).resolve().parent/'validate_head_reshape.py'),run_name='__main__')
