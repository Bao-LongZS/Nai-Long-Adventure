"""Validate the current head-side refinement against its fixed preceding version."""
import runpy
from pathlib import Path
runpy.run_path(str(Path(__file__).resolve().parent/'validate_head_side_continuity.py'),run_name='__main__')
